<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/contact.css">
    <title>Document</title>
</head>
<body>
    
<header>
            <img class="logo" src="img/beter.png" alt="logo">
            <ul class="nav">
                <li><a href="home.php" >Home</a></li>
                <li><a href="#">informatie</a></li>
                <li><a href="#">games</a></li>
                <li><a href="" >voedsel</a></li>
                
            </ul>
            <a class="button" href="contact.php" class="active"><button>Contact</button></a>
        </header>
        <div class="wrapper">

<pre>
<Div class="contact">
Tel:06 0725476600
<a href="https://mail.google.com/">Email:GertJan@gmail.com</a>
</div>


</pre>
</div>
</body>
</html>
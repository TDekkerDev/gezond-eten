<header>
            <img class="logo" src="../img/beter.png" alt="logo">
            <ul class="nav">
                <li><a href="home.php" class="active">Home</a></li>
                <li><a href="#">informatie</a></li>
                <li><a href="#">games</a></li>
                <li><a href="#">voedsel</a></li>
                <li><a href="php/vragg.php">vragenlijft</a></li>

            </ul>
            <a class="button" href="contact.php"><button>Contact</button></a>
        </header>